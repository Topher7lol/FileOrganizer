# Import important modules
# Coded by Topher :3
import os
import shutil

def organize_files(folder_path):
    folders = {
        "Images": ["png", "jpg", "jpeg", "gif", "bmp"],
        "Videos": ["mp4", "mkv", "avi", "mov", "flv"],
        "Audios": ["mp3", "wav", "flac", "aac", "ogg"],
        "Documents": ["doc", "docx", "txt", "pdf", "xls", "xlsx", "ppt", "pptx"],
        "Others": [] # Add anything you want here, whether it's .exe's or .json's.
    }

    # Create some destination folders if they don't exist.
    for folder in folders:
        os.makedirs(os.path.join(folder_path, folder), exist_ok=True)

    # Organize the files
    for file_name in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file_name)

        if os.path.isfile(file_path) and file_name not in ["organize_files.py", "organize_files.bat"]:
            # Determine the file type.
            file_extension = file_name.split(".")[-1].lower()
            moved = False

            # Move to the correct folder.
            for folder, extensions in folders.items():
                if file_extension in extensions:
                    destination_folder = os.path.join(folder_path, folder)
                    shutil.move(file_path, os.path.join(destination_folder, file_name))
                    moved = True
                    break

            # Move to "Others" folder if the file type is not recognized.
            if not moved:
                destination_folder = os.path.join(folder_path, "Others")
                shutil.move(file_path, os.path.join(destination_folder, file_name))

if __name__ == "__main__":
    current_directory = os.getcwd()
    organize_files(current_directory)
    print("Files organized successfully!")

# This took a while to make :v